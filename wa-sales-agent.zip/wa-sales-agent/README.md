# WA Sales Agent

AI Agent WhatsApp → ERP Sales Order menggunakan Python + FastAPI + Claude AI.

## Stack
- **Backend**: Python 3.12, FastAPI
- **AI**: Claude (Anthropic) + LangChain
- **WhatsApp**: WAHA (self-hosted)
- **Database**: PostgreSQL + pgvector
- **Cache/Session**: Redis
- **ERP**: Custom REST API

## Struktur project

```
wa-sales-agent/
├── app/
│   ├── main.py                  # FastAPI entrypoint
│   ├── core/
│   │   ├── settings.py          # Konfigurasi dari .env
│   │   └── logging.py           # Structured logging
│   ├── api/routes/
│   │   ├── webhook.py           # Endpoint WAHA webhook
│   │   └── health.py            # Health check
│   ├── db/
│   │   ├── database.py          # SQLAlchemy async engine
│   │   └── redis_client.py      # Redis + SessionStore
│   ├── models/
│   │   └── customer.py          # WACustomerMap, ConversationLog
│   └── services/
│       ├── ai/                  # AI Agent & LLM logic
│       ├── whatsapp/            # WAHA client
│       ├── erp/                 # Custom ERP client
│       └── vector/              # Embedding & vector search
├── tests/
├── docker-compose.yml
├── Dockerfile
├── requirements.txt
└── .env.example
```

## Quick start

### 1. Clone & setup env
```bash
cp .env.example .env
# Edit .env sesuai konfigurasi kamu
```

### 2. Jalankan semua service
```bash
docker-compose up -d postgres redis waha
```

### 3. Install dependencies
```bash
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 4. Jalankan app
```bash
uvicorn app.main:app --reload
```

API docs: http://localhost:8000/docs

### 5. Setup WAHA webhook
Di WAHA dashboard (http://localhost:3000), set webhook URL ke:
```
http://your-server:8000/webhook/waha
```

## Tahap development berikutnya
- [ ] Webhook receiver (parse pesan WAHA)
- [ ] Identity resolution (nomor WA → customer_id)
- [ ] ERP client (product lookup, stock check)
- [ ] Vector store setup + product embedding
- [ ] AI Agent core (LangChain + tools)
- [ ] Sales order creation flow
