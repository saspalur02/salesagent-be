from fastapi import APIRouter, Request, HTTPException
from app.core.logging import get_logger

router = APIRouter()
logger = get_logger(__name__)


@router.post("/waha")
async def waha_webhook(request: Request):
    """
    Endpoint ini menerima pesan masuk dari WAHA.
    Akan diimplementasikan lengkap di tahap Webhook Receiver.
    """
    payload = await request.json()
    logger.info("webhook received", payload=payload)

    # TODO: implement full webhook handler
    return {"status": "received"}
