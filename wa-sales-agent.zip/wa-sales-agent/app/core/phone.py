import re


def normalize_phone(number: str) -> str:
    """
    Normalisasi nomor HP ke format tanpa awalan +/0 dan tanpa spasi/strip.

    Contoh input → output:
      +6281234567890  → 6281234567890
      081234567890    → 6281234567890
      62-812-3456-789 → 6281234567890
      6281234567890   → 6281234567890
    """
    # Hapus semua karakter non-digit
    digits = re.sub(r"\D", "", number)

    # Konversi awalan 0 → 62 (Indonesia)
    if digits.startswith("0"):
        digits = "62" + digits[1:]

    return digits


def to_waha_id(number: str) -> str:
    """Konversi nomor ke format WAHA: 6281234567890@c.us"""
    return f"{normalize_phone(number)}@c.us"


def from_waha_id(waha_id: str) -> str:
    """Ekstrak nomor dari format WAHA: 6281234567890@c.us → 6281234567890"""
    return waha_id.split("@")[0]
