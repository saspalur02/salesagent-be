from datetime import datetime
from sqlalchemy import String, Boolean, DateTime, Text, Integer, func
from sqlalchemy.orm import Mapped, mapped_column
from app.db.database import Base


class WACustomerMap(Base):
    """Mapping nomor WhatsApp → customer_id di ERP."""

    __tablename__ = "wa_customer_map"

    wa_number: Mapped[str] = mapped_column(String(20), primary_key=True)
    customer_id: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    customer_name: Mapped[str] = mapped_column(String(200), nullable=False)
    contact_name: Mapped[str | None] = mapped_column(String(100), nullable=True)
    is_verified: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    def __repr__(self) -> str:
        return f"<WACustomerMap {self.wa_number} → {self.customer_id}>"


class ConversationLog(Base):
    """Log percakapan untuk audit trail dan debugging."""

    __tablename__ = "conversation_log"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    wa_number: Mapped[str] = mapped_column(String(20), index=True)
    customer_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
    role: Mapped[str] = mapped_column(String(10))   # user | assistant
    message: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
